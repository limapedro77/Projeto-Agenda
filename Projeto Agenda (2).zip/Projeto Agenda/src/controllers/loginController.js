exports.index = async (req, res) => {
    res.render('login')
}

exports.register = async (req, res) => {
    res.send(req.body.email, req.body.password)
}