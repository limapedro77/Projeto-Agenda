const Home = require('../models/HomeModel');

exports.index = async (req, res) => {
  res.render('index')
}
