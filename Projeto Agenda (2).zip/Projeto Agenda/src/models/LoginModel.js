const mongoose = require('mongoose');

const LoginSchema = new mongoose.Schema({
    usuario: { type: String, required: true },
    senha: String
});

module.exports = mongoose.model('Login', LoginSchema);

class Login {
    constructor(body) {
        this.body = body
        this.errors = []
        this.user = null
    }
}