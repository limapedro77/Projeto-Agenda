import 'core-js/stable';
import 'regenerator-runtime/runtime';

console.log('Olá mundo 3');
// Removido import do CSS para usar apenas Bootstrap
// import './assets/css/style.css';
